package Builder;

public class patientInformation {
    private final String RecordDate;
    private final String Description;
    private final String patientName;
    
    public patientInformation(String RecordDate,String patientName, String Description){
       this.RecordDate=RecordDate;
       this.Description=Description;
       this.patientName=patientName;  
    }

    public String getRecordDate() {
        return RecordDate;
    }

    public String getDescription() {
        return Description;
    }

    public String getPatientName() {
        return patientName;
    }
}
