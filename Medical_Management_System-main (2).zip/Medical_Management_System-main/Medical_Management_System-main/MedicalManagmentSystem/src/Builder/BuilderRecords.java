package Builder;

public class BuilderRecords {
    private int RecordID;
    private String RecordDate;
    private String Description;
    private String patientName;
    
     public BuilderRecords set_RecordDate(String RecordDate){
    this.RecordDate=RecordDate;
    return this;
    }
     
    public BuilderRecords set_Description (String Description){
    this.Description=Description;
    return this;
    }
    public BuilderRecords set_PatientName (String patientName){
    this.patientName=patientName;
    return this;
    }
    
    public patientInformation buildd(){
        return new patientInformation (RecordDate,patientName,Description);
    }  
}