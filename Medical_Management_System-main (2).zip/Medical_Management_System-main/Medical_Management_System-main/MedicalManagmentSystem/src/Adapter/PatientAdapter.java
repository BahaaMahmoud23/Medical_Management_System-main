package Adapter;

import java.util.List;
import ProtoType.*;

public interface PatientAdapter {
    public String getPatientName();
    public void setPatientName(String patientName);
    public String getDoctorName();
    public void setDoctorName(String doctorName);
    public String getDoctorSpaisialst();
    public void setDoctorSpaisialst(String doctorSpaisialst);
    public String getAppointmentDate();
    public void setAppointmentDate(String appointmentDate);
}
