package Adapter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import ProtoType.*;

public class PatientAdapterImpl implements PatientAdapter{
    
    String patientName;
    String doctorName;
    String doctorSpaisialst;
    String appointmentDate;

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public void setDoctorName(String doctorName) {
        this.doctorName = doctorName;
    }

    public String getDoctorSpaisialst() {
        return doctorSpaisialst;
    }

    public void setDoctorSpaisialst(String doctorSpaisialst) {
        this.doctorSpaisialst = doctorSpaisialst;
    }

    public String getAppointmentDate() {
        return appointmentDate;
    }

    public void setAppointmentDate(String appointmentDate) {
        this.appointmentDate = appointmentDate;
    }
    
    
}
