package Factory_Role;
import javax.swing.JOptionPane;

public class Admin extends Role{
    public Admin(String name) {
        super(name);
    }

    @Override
    public void welcomePane() {
        JOptionPane.showMessageDialog(null, "Welcome Admin " + this.name,"user Admin",JOptionPane.INFORMATION_MESSAGE);
    }
}
