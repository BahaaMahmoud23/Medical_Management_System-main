package Factory_Role;
import javax.swing.JOptionPane;

public class Receptionist extends Role{
    public Receptionist(String name) {
        super(name);
    }

    @Override
    public void welcomePane() {
        JOptionPane.showMessageDialog(null, "Welcome Receptionist : " + this.name,"user Receptionist",JOptionPane.INFORMATION_MESSAGE);
    }
}
