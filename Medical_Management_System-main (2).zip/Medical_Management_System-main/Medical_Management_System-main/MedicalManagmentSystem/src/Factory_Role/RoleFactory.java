package Factory_Role;

public class RoleFactory {
    public static Role getRole(String roleType, String name) {
        if (roleType == null) {
            throw new IllegalArgumentException("Role type cannot be null.");
        }

        switch (roleType.toLowerCase()) {
            case "doctor":
                return new Doctor(name);
            case "receptionist":
                return new Receptionist(name);
            case "admin":
                return new Admin(name);
            default:
                throw new IllegalArgumentException("Unknown role type: " + roleType);
        }
    }
}
