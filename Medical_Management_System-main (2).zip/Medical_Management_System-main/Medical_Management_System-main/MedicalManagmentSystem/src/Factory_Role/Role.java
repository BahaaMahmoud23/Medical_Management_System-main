package Factory_Role;

public abstract class Role {
    protected String name;

    public Role(String name) {
        this.name = name;
    }

    public abstract void welcomePane();
}
