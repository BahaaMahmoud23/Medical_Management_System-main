package Factory_Role;
import javax.swing.JOptionPane;

public class Doctor extends Role{
    public Doctor(String name) {
        super(name);
    }

    @Override
    public void welcomePane() {
        JOptionPane.showMessageDialog(null, "Welcome Doctor : " + this.name,"user doctor",JOptionPane.INFORMATION_MESSAGE);
    }
}
