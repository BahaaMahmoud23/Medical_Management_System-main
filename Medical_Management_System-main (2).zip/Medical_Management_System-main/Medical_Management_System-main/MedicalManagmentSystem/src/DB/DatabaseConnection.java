package DB;
import com.sun.source.util.DocTrees;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.*;
import javax.swing.table.*;


public class DatabaseConnection {
    
    private static final String URL = "jdbc:sqlserver://localhost:1433;databaseName=MedicalClinic;encrypt=true;trustServerCertificate=true;";
    private static final String USER = "sa";
    private static final String PASSWORD = "12345";
    private static Connection connection;
    private static DatabaseConnection instance;
    
    private DatabaseConnection (){
        try {
            connection = DriverManager.getConnection(URL,USER,PASSWORD);
            System.out.println("Database connection established!");
        } catch (SQLException e){
            e.printStackTrace();
        }
    }
    public static DatabaseConnection getInstance(){
        if (instance == null){
            instance = new DatabaseConnection();
        }
        return instance;
    }
    
    public static Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
        }
        return connection;
    }
    
    public void test(){
        String query = "INSERT INTO users (Username, Password, Role) VALUES (?, ?, ?)";

        try (PreparedStatement preparedStatement = DatabaseConnection.getConnection().prepareStatement(query)) {
            preparedStatement.setString(1, "test");
            preparedStatement.setString(2, "test");
            preparedStatement.setString(3, "test");
            preparedStatement.setInt(4, 1);
            preparedStatement.setString(5, "test");
            preparedStatement.setInt(6, 1);

            int rowsInserted = preparedStatement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("true");;
            } else {
                System.out.println("flase");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public DefaultTableModel viewAppointments(){
        String query = "SELECT * FROM Appointments";
        DefaultTableModel tableModel = new DefaultTableModel(new Object[]{"Patient Name", "Doctor Name", "Doctor Spaicialst", "Appointment Date"}, 0);
        try (PreparedStatement preparedStatement = DatabaseConnection.getConnection().prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {
            
            // Clear the table before adding new rows
            tableModel.setRowCount(0);
            
            while (resultSet.next()) {
                String patientName = resultSet.getString("Patientname");
                String doctorName = resultSet.getString("Doctorname");
                String doctorSpaisialst = resultSet.getString("Doctorspaisalist");
                String appointmentDate = resultSet.getString("AppointmentDate");
                
                // Add a row to the table model
                tableModel.addRow(new Object[]{patientName, doctorName, doctorSpaisialst, appointmentDate});    
            }
            return tableModel;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }    
    }
    
        public DefaultTableModel viewMedicalRecords(){
        String query = "SELECT * FROM medicalRecords";
        DefaultTableModel tableModel = new DefaultTableModel(new Object[]{"Patient Name", "Date", "Descreption"}, 0);
        try (PreparedStatement preparedStatement = DatabaseConnection.getConnection().prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {
            
            tableModel.setRowCount(0);
            
            while (resultSet.next()) {
                String patientName = resultSet.getString("patientName");
                String date = resultSet.getString("date");
                String descreption = resultSet.getString("description");
                
                tableModel.addRow(new Object[]{patientName, date, descreption});    
            }
            return tableModel;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }    
    }

}